﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculo_Nómina
{
    public partial class frm8 : Form
    {
        public frm8()
        {
            InitializeComponent();
        }

        private void btn_Siguiente_Bono_Click(object sender, EventArgs e)
        {
            Form btn_Siguiente_Bono = new frm9();
            btn_Siguiente_Bono.Show ();
        }

        private void btn_Salir_Bono_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Limpiar_Bono_Click(object sender, EventArgs e)
        {
            limpiar();
        }

        public void limpiar()
        {
            txtResultadoAñoIngreso.Clear();
            cmbBonoOpciones.SelectedItem = null;
        }

    }
}

