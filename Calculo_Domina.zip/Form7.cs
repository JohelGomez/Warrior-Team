﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculo_Nómina
{
    public partial class frm7 : Form
    {
        public frm7()
        {
            InitializeComponent();
        }

        private void btnSiguiente_CalculoPlanilla_Click(object sender, EventArgs e)
        {
            Form btnSiguiente_CalculoPlanilla = new frm8();
            btnSiguiente_CalculoPlanilla.Show();

        }

        private void btn_Salir_CalculoPlanilla_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Limpiar_CalculoPlanilla_Click(object sender, EventArgs e)
        {
            limpiar();
        }

        public void limpiar()
        {
            txtResultadoComprobanteConsecutivo.Clear();
            txtResultadoFechaIngresoPlanilla.Clear();
            txtResultadoHoraIngresoPlanilla.Clear();
            txtResultadoHorasOrdinarias.Clear();
            cmbResultadoHorasExtras.SelectedItem = null;
            txtResultadoCostoPorHora.Clear();
        }
    }
}
