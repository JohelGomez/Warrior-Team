﻿namespace Calculo_Nómina
{
    partial class frm4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpDatosEmpleado = new System.Windows.Forms.GroupBox();
            this.btn_Guardar_DatosEmpleado = new System.Windows.Forms.Button();
            this.cmbMantenimientoProfesion = new System.Windows.Forms.ComboBox();
            this.lbl_MantenimientoProfesión = new System.Windows.Forms.Label();
            this.cmbMantenimientoGenero = new System.Windows.Forms.ComboBox();
            this.txtMantenimientoEdad = new System.Windows.Forms.TextBox();
            this.lbl_MantenimientoEdad = new System.Windows.Forms.Label();
            this.lbl_MantenimientoFechaNacimiento = new System.Windows.Forms.Label();
            this.txtMantenimientoSegundoApellido = new System.Windows.Forms.TextBox();
            this.txtMantenimientoPrimerApellido = new System.Windows.Forms.TextBox();
            this.lbl_MantenimientoGenero = new System.Windows.Forms.Label();
            this.lbl_MantenimientoSegundoApellido = new System.Windows.Forms.Label();
            this.lbl_MantenimientoPrimerApellido = new System.Windows.Forms.Label();
            this.lbl_MantenimientoNombre = new System.Windows.Forms.Label();
            this.txtMantenimientoNombre = new System.Windows.Forms.TextBox();
            this.txtMantenimientoCédula = new System.Windows.Forms.TextBox();
            this.lbl_MantenimientoCédula = new System.Windows.Forms.Label();
            this.grpResultadoEmpleado = new System.Windows.Forms.GroupBox();
            this.btnModificar = new System.Windows.Forms.Button();
            this.txtResultadoMantenimientoFechaNacimiento = new System.Windows.Forms.TextBox();
            this.txtResultadoMantenimientoEdad = new System.Windows.Forms.TextBox();
            this.txtResultadoMantenimientoSexo = new System.Windows.Forms.TextBox();
            this.lbl_ResultadoMantenimientoEdad = new System.Windows.Forms.Label();
            this.lbl_ResultadoMantenimientoFechaNacimiento = new System.Windows.Forms.Label();
            this.lbl_ResultadoMantenimientoGenero = new System.Windows.Forms.Label();
            this.lbl_ResultadoMantenimientoNombre = new System.Windows.Forms.Label();
            this.txtResultadoMantenimientoNombre = new System.Windows.Forms.TextBox();
            this.txtResultadoMantenimientoCédula = new System.Windows.Forms.TextBox();
            this.lbl_ResultadoMantenimientoCédula = new System.Windows.Forms.Label();
            this.btn_Limpiar_DatosEmpleado = new System.Windows.Forms.Button();
            this.btn_Salir_ResultadodelRegistro = new System.Windows.Forms.Button();
            this.dtp_ResultadoFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.grpDatosEmpleado.SuspendLayout();
            this.grpResultadoEmpleado.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpDatosEmpleado
            // 
            this.grpDatosEmpleado.BackColor = System.Drawing.SystemColors.MenuBar;
            this.grpDatosEmpleado.Controls.Add(this.dtp_ResultadoFechaNacimiento);
            this.grpDatosEmpleado.Controls.Add(this.btn_Limpiar_DatosEmpleado);
            this.grpDatosEmpleado.Controls.Add(this.btn_Guardar_DatosEmpleado);
            this.grpDatosEmpleado.Controls.Add(this.cmbMantenimientoProfesion);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoProfesión);
            this.grpDatosEmpleado.Controls.Add(this.cmbMantenimientoGenero);
            this.grpDatosEmpleado.Controls.Add(this.txtMantenimientoEdad);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoEdad);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoFechaNacimiento);
            this.grpDatosEmpleado.Controls.Add(this.txtMantenimientoSegundoApellido);
            this.grpDatosEmpleado.Controls.Add(this.txtMantenimientoPrimerApellido);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoGenero);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoSegundoApellido);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoPrimerApellido);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoNombre);
            this.grpDatosEmpleado.Controls.Add(this.txtMantenimientoNombre);
            this.grpDatosEmpleado.Controls.Add(this.txtMantenimientoCédula);
            this.grpDatosEmpleado.Controls.Add(this.lbl_MantenimientoCédula);
            this.grpDatosEmpleado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDatosEmpleado.Location = new System.Drawing.Point(12, 12);
            this.grpDatosEmpleado.Name = "grpDatosEmpleado";
            this.grpDatosEmpleado.Size = new System.Drawing.Size(818, 276);
            this.grpDatosEmpleado.TabIndex = 2;
            this.grpDatosEmpleado.TabStop = false;
            this.grpDatosEmpleado.Text = "Datos Empleado";
            // 
            // btn_Guardar_DatosEmpleado
            // 
            this.btn_Guardar_DatosEmpleado.Location = new System.Drawing.Point(304, 226);
            this.btn_Guardar_DatosEmpleado.Name = "btn_Guardar_DatosEmpleado";
            this.btn_Guardar_DatosEmpleado.Size = new System.Drawing.Size(101, 28);
            this.btn_Guardar_DatosEmpleado.TabIndex = 4;
            this.btn_Guardar_DatosEmpleado.Text = "Guardar";
            this.btn_Guardar_DatosEmpleado.UseVisualStyleBackColor = true;
            // 
            // cmbMantenimientoProfesion
            // 
            this.cmbMantenimientoProfesion.FormattingEnabled = true;
            this.cmbMantenimientoProfesion.Items.AddRange(new object[] {
            "Digitador",
            "Analista de Datos",
            "Arquitecto de Software",
            "Analista de Ciber Seguridad"});
            this.cmbMantenimientoProfesion.Location = new System.Drawing.Point(598, 150);
            this.cmbMantenimientoProfesion.Name = "cmbMantenimientoProfesion";
            this.cmbMantenimientoProfesion.Size = new System.Drawing.Size(140, 28);
            this.cmbMantenimientoProfesion.TabIndex = 3;
            // 
            // lbl_MantenimientoProfesión
            // 
            this.lbl_MantenimientoProfesión.AutoSize = true;
            this.lbl_MantenimientoProfesión.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoProfesión.Location = new System.Drawing.Point(381, 150);
            this.lbl_MantenimientoProfesión.Name = "lbl_MantenimientoProfesión";
            this.lbl_MantenimientoProfesión.Size = new System.Drawing.Size(193, 20);
            this.lbl_MantenimientoProfesión.TabIndex = 3;
            this.lbl_MantenimientoProfesión.Text = "Seleccione su profesión:";
            // 
            // cmbMantenimientoGenero
            // 
            this.cmbMantenimientoGenero.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMantenimientoGenero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMantenimientoGenero.FormattingEnabled = true;
            this.cmbMantenimientoGenero.Items.AddRange(new object[] {
            "Masculino",
            "Femenino"});
            this.cmbMantenimientoGenero.Location = new System.Drawing.Point(598, 110);
            this.cmbMantenimientoGenero.Name = "cmbMantenimientoGenero";
            this.cmbMantenimientoGenero.Size = new System.Drawing.Size(140, 28);
            this.cmbMantenimientoGenero.TabIndex = 13;
            // 
            // txtMantenimientoEdad
            // 
            this.txtMantenimientoEdad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMantenimientoEdad.Location = new System.Drawing.Point(598, 72);
            this.txtMantenimientoEdad.Name = "txtMantenimientoEdad";
            this.txtMantenimientoEdad.Size = new System.Drawing.Size(140, 27);
            this.txtMantenimientoEdad.TabIndex = 12;
            this.txtMantenimientoEdad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMantenimientoEdad_KeyPress);
            // 
            // lbl_MantenimientoEdad
            // 
            this.lbl_MantenimientoEdad.AutoSize = true;
            this.lbl_MantenimientoEdad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoEdad.Location = new System.Drawing.Point(527, 75);
            this.lbl_MantenimientoEdad.Name = "lbl_MantenimientoEdad";
            this.lbl_MantenimientoEdad.Size = new System.Drawing.Size(47, 20);
            this.lbl_MantenimientoEdad.TabIndex = 8;
            this.lbl_MantenimientoEdad.Text = "Edad";
            // 
            // lbl_MantenimientoFechaNacimiento
            // 
            this.lbl_MantenimientoFechaNacimiento.AutoSize = true;
            this.lbl_MantenimientoFechaNacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoFechaNacimiento.Location = new System.Drawing.Point(415, 39);
            this.lbl_MantenimientoFechaNacimiento.Name = "lbl_MantenimientoFechaNacimiento";
            this.lbl_MantenimientoFechaNacimiento.Size = new System.Drawing.Size(164, 20);
            this.lbl_MantenimientoFechaNacimiento.TabIndex = 7;
            this.lbl_MantenimientoFechaNacimiento.Text = "Fecha de nacimiento";
            // 
            // txtMantenimientoSegundoApellido
            // 
            this.txtMantenimientoSegundoApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMantenimientoSegundoApellido.Location = new System.Drawing.Point(211, 151);
            this.txtMantenimientoSegundoApellido.Name = "txtMantenimientoSegundoApellido";
            this.txtMantenimientoSegundoApellido.Size = new System.Drawing.Size(140, 27);
            this.txtMantenimientoSegundoApellido.TabIndex = 10;
            this.txtMantenimientoSegundoApellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMantenimientoSegundoApellido_KeyPress);
            // 
            // txtMantenimientoPrimerApellido
            // 
            this.txtMantenimientoPrimerApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMantenimientoPrimerApellido.Location = new System.Drawing.Point(211, 110);
            this.txtMantenimientoPrimerApellido.Name = "txtMantenimientoPrimerApellido";
            this.txtMantenimientoPrimerApellido.Size = new System.Drawing.Size(140, 27);
            this.txtMantenimientoPrimerApellido.TabIndex = 9;
            this.txtMantenimientoPrimerApellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMantenimientoPrimerApellido_KeyPress);
            // 
            // lbl_MantenimientoGenero
            // 
            this.lbl_MantenimientoGenero.AutoSize = true;
            this.lbl_MantenimientoGenero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoGenero.Location = new System.Drawing.Point(510, 110);
            this.lbl_MantenimientoGenero.Name = "lbl_MantenimientoGenero";
            this.lbl_MantenimientoGenero.Size = new System.Drawing.Size(64, 20);
            this.lbl_MantenimientoGenero.TabIndex = 2;
            this.lbl_MantenimientoGenero.Text = "Genero";
            // 
            // lbl_MantenimientoSegundoApellido
            // 
            this.lbl_MantenimientoSegundoApellido.AutoSize = true;
            this.lbl_MantenimientoSegundoApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoSegundoApellido.Location = new System.Drawing.Point(54, 150);
            this.lbl_MantenimientoSegundoApellido.Name = "lbl_MantenimientoSegundoApellido";
            this.lbl_MantenimientoSegundoApellido.Size = new System.Drawing.Size(138, 20);
            this.lbl_MantenimientoSegundoApellido.TabIndex = 6;
            this.lbl_MantenimientoSegundoApellido.Text = "Segundo Apellido";
            // 
            // lbl_MantenimientoPrimerApellido
            // 
            this.lbl_MantenimientoPrimerApellido.AutoSize = true;
            this.lbl_MantenimientoPrimerApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoPrimerApellido.Location = new System.Drawing.Point(69, 110);
            this.lbl_MantenimientoPrimerApellido.Name = "lbl_MantenimientoPrimerApellido";
            this.lbl_MantenimientoPrimerApellido.Size = new System.Drawing.Size(123, 20);
            this.lbl_MantenimientoPrimerApellido.TabIndex = 5;
            this.lbl_MantenimientoPrimerApellido.Text = "Primer Apellido";
            // 
            // lbl_MantenimientoNombre
            // 
            this.lbl_MantenimientoNombre.AutoSize = true;
            this.lbl_MantenimientoNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoNombre.Location = new System.Drawing.Point(124, 75);
            this.lbl_MantenimientoNombre.Name = "lbl_MantenimientoNombre";
            this.lbl_MantenimientoNombre.Size = new System.Drawing.Size(68, 20);
            this.lbl_MantenimientoNombre.TabIndex = 4;
            this.lbl_MantenimientoNombre.Text = "Nombre";
            // 
            // txtMantenimientoNombre
            // 
            this.txtMantenimientoNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMantenimientoNombre.Location = new System.Drawing.Point(211, 77);
            this.txtMantenimientoNombre.Name = "txtMantenimientoNombre";
            this.txtMantenimientoNombre.Size = new System.Drawing.Size(140, 27);
            this.txtMantenimientoNombre.TabIndex = 3;
            this.txtMantenimientoNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMantenimientoNombre_KeyPress);
            // 
            // txtMantenimientoCédula
            // 
            this.txtMantenimientoCédula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMantenimientoCédula.Location = new System.Drawing.Point(211, 36);
            this.txtMantenimientoCédula.Name = "txtMantenimientoCédula";
            this.txtMantenimientoCédula.Size = new System.Drawing.Size(140, 27);
            this.txtMantenimientoCédula.TabIndex = 2;
            this.txtMantenimientoCédula.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMantenimientoCédula_KeyPress);
            // 
            // lbl_MantenimientoCédula
            // 
            this.lbl_MantenimientoCédula.AutoSize = true;
            this.lbl_MantenimientoCédula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MantenimientoCédula.Location = new System.Drawing.Point(131, 39);
            this.lbl_MantenimientoCédula.Name = "lbl_MantenimientoCédula";
            this.lbl_MantenimientoCédula.Size = new System.Drawing.Size(61, 20);
            this.lbl_MantenimientoCédula.TabIndex = 2;
            this.lbl_MantenimientoCédula.Text = "Cédula";
            // 
            // grpResultadoEmpleado
            // 
            this.grpResultadoEmpleado.BackColor = System.Drawing.SystemColors.MenuBar;
            this.grpResultadoEmpleado.Controls.Add(this.btn_Salir_ResultadodelRegistro);
            this.grpResultadoEmpleado.Controls.Add(this.btnModificar);
            this.grpResultadoEmpleado.Controls.Add(this.txtResultadoMantenimientoSexo);
            this.grpResultadoEmpleado.Controls.Add(this.txtResultadoMantenimientoFechaNacimiento);
            this.grpResultadoEmpleado.Controls.Add(this.txtResultadoMantenimientoEdad);
            this.grpResultadoEmpleado.Controls.Add(this.lbl_ResultadoMantenimientoEdad);
            this.grpResultadoEmpleado.Controls.Add(this.lbl_ResultadoMantenimientoFechaNacimiento);
            this.grpResultadoEmpleado.Controls.Add(this.lbl_ResultadoMantenimientoGenero);
            this.grpResultadoEmpleado.Controls.Add(this.lbl_ResultadoMantenimientoNombre);
            this.grpResultadoEmpleado.Controls.Add(this.txtResultadoMantenimientoNombre);
            this.grpResultadoEmpleado.Controls.Add(this.txtResultadoMantenimientoCédula);
            this.grpResultadoEmpleado.Controls.Add(this.lbl_ResultadoMantenimientoCédula);
            this.grpResultadoEmpleado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpResultadoEmpleado.Location = new System.Drawing.Point(12, 304);
            this.grpResultadoEmpleado.Name = "grpResultadoEmpleado";
            this.grpResultadoEmpleado.Size = new System.Drawing.Size(818, 184);
            this.grpResultadoEmpleado.TabIndex = 3;
            this.grpResultadoEmpleado.TabStop = false;
            this.grpResultadoEmpleado.Text = "Resultado del registro";
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(711, 147);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(101, 28);
            this.btnModificar.TabIndex = 11;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            // 
            // txtResultadoMantenimientoFechaNacimiento
            // 
            this.txtResultadoMantenimientoFechaNacimiento.Enabled = false;
            this.txtResultadoMantenimientoFechaNacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultadoMantenimientoFechaNacimiento.Location = new System.Drawing.Point(190, 87);
            this.txtResultadoMantenimientoFechaNacimiento.Name = "txtResultadoMantenimientoFechaNacimiento";
            this.txtResultadoMantenimientoFechaNacimiento.Size = new System.Drawing.Size(140, 27);
            this.txtResultadoMantenimientoFechaNacimiento.TabIndex = 10;
            // 
            // txtResultadoMantenimientoEdad
            // 
            this.txtResultadoMantenimientoEdad.Enabled = false;
            this.txtResultadoMantenimientoEdad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultadoMantenimientoEdad.Location = new System.Drawing.Point(411, 87);
            this.txtResultadoMantenimientoEdad.Name = "txtResultadoMantenimientoEdad";
            this.txtResultadoMantenimientoEdad.Size = new System.Drawing.Size(140, 27);
            this.txtResultadoMantenimientoEdad.TabIndex = 9;
            // 
            // txtResultadoMantenimientoSexo
            // 
            this.txtResultadoMantenimientoSexo.Enabled = false;
            this.txtResultadoMantenimientoSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultadoMantenimientoSexo.Location = new System.Drawing.Point(641, 86);
            this.txtResultadoMantenimientoSexo.Name = "txtResultadoMantenimientoSexo";
            this.txtResultadoMantenimientoSexo.Size = new System.Drawing.Size(140, 27);
            this.txtResultadoMantenimientoSexo.TabIndex = 8;
            // 
            // lbl_ResultadoMantenimientoEdad
            // 
            this.lbl_ResultadoMantenimientoEdad.AutoSize = true;
            this.lbl_ResultadoMantenimientoEdad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ResultadoMantenimientoEdad.Location = new System.Drawing.Point(358, 93);
            this.lbl_ResultadoMantenimientoEdad.Name = "lbl_ResultadoMantenimientoEdad";
            this.lbl_ResultadoMantenimientoEdad.Size = new System.Drawing.Size(47, 20);
            this.lbl_ResultadoMantenimientoEdad.TabIndex = 6;
            this.lbl_ResultadoMantenimientoEdad.Text = "Edad";
            // 
            // lbl_ResultadoMantenimientoFechaNacimiento
            // 
            this.lbl_ResultadoMantenimientoFechaNacimiento.AutoSize = true;
            this.lbl_ResultadoMantenimientoFechaNacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ResultadoMantenimientoFechaNacimiento.Location = new System.Drawing.Point(20, 93);
            this.lbl_ResultadoMantenimientoFechaNacimiento.Name = "lbl_ResultadoMantenimientoFechaNacimiento";
            this.lbl_ResultadoMantenimientoFechaNacimiento.Size = new System.Drawing.Size(164, 20);
            this.lbl_ResultadoMantenimientoFechaNacimiento.TabIndex = 5;
            this.lbl_ResultadoMantenimientoFechaNacimiento.Text = "Fecha de nacimiento";
            // 
            // lbl_ResultadoMantenimientoGenero
            // 
            this.lbl_ResultadoMantenimientoGenero.AutoSize = true;
            this.lbl_ResultadoMantenimientoGenero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ResultadoMantenimientoGenero.Location = new System.Drawing.Point(571, 93);
            this.lbl_ResultadoMantenimientoGenero.Name = "lbl_ResultadoMantenimientoGenero";
            this.lbl_ResultadoMantenimientoGenero.Size = new System.Drawing.Size(64, 20);
            this.lbl_ResultadoMantenimientoGenero.TabIndex = 4;
            this.lbl_ResultadoMantenimientoGenero.Text = "Genero";
            // 
            // lbl_ResultadoMantenimientoNombre
            // 
            this.lbl_ResultadoMantenimientoNombre.AutoSize = true;
            this.lbl_ResultadoMantenimientoNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ResultadoMantenimientoNombre.Location = new System.Drawing.Point(249, 45);
            this.lbl_ResultadoMantenimientoNombre.Name = "lbl_ResultadoMantenimientoNombre";
            this.lbl_ResultadoMantenimientoNombre.Size = new System.Drawing.Size(172, 20);
            this.lbl_ResultadoMantenimientoNombre.TabIndex = 3;
            this.lbl_ResultadoMantenimientoNombre.Text = "Nombre del empleado";
            // 
            // txtResultadoMantenimientoNombre
            // 
            this.txtResultadoMantenimientoNombre.Enabled = false;
            this.txtResultadoMantenimientoNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultadoMantenimientoNombre.Location = new System.Drawing.Point(437, 45);
            this.txtResultadoMantenimientoNombre.Name = "txtResultadoMantenimientoNombre";
            this.txtResultadoMantenimientoNombre.Size = new System.Drawing.Size(344, 27);
            this.txtResultadoMantenimientoNombre.TabIndex = 2;
            // 
            // txtResultadoMantenimientoCédula
            // 
            this.txtResultadoMantenimientoCédula.Enabled = false;
            this.txtResultadoMantenimientoCédula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultadoMantenimientoCédula.Location = new System.Drawing.Point(98, 41);
            this.txtResultadoMantenimientoCédula.Name = "txtResultadoMantenimientoCédula";
            this.txtResultadoMantenimientoCédula.Size = new System.Drawing.Size(140, 27);
            this.txtResultadoMantenimientoCédula.TabIndex = 1;
            // 
            // lbl_ResultadoMantenimientoCédula
            // 
            this.lbl_ResultadoMantenimientoCédula.AutoSize = true;
            this.lbl_ResultadoMantenimientoCédula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ResultadoMantenimientoCédula.Location = new System.Drawing.Point(20, 45);
            this.lbl_ResultadoMantenimientoCédula.Name = "lbl_ResultadoMantenimientoCédula";
            this.lbl_ResultadoMantenimientoCédula.Size = new System.Drawing.Size(61, 20);
            this.lbl_ResultadoMantenimientoCédula.TabIndex = 0;
            this.lbl_ResultadoMantenimientoCédula.Text = "Cédula";
            // 
            // btn_Limpiar_DatosEmpleado
            // 
            this.btn_Limpiar_DatosEmpleado.Location = new System.Drawing.Point(419, 226);
            this.btn_Limpiar_DatosEmpleado.Name = "btn_Limpiar_DatosEmpleado";
            this.btn_Limpiar_DatosEmpleado.Size = new System.Drawing.Size(101, 28);
            this.btn_Limpiar_DatosEmpleado.TabIndex = 15;
            this.btn_Limpiar_DatosEmpleado.Text = "Limpiar";
            this.btn_Limpiar_DatosEmpleado.UseVisualStyleBackColor = true;
            this.btn_Limpiar_DatosEmpleado.Click += new System.EventHandler(this.btn_Limpiar_DatosEmpleado_Click);
            // 
            // btn_Salir_ResultadodelRegistro
            // 
            this.btn_Salir_ResultadodelRegistro.Location = new System.Drawing.Point(6, 147);
            this.btn_Salir_ResultadodelRegistro.Name = "btn_Salir_ResultadodelRegistro";
            this.btn_Salir_ResultadodelRegistro.Size = new System.Drawing.Size(101, 28);
            this.btn_Salir_ResultadodelRegistro.TabIndex = 14;
            this.btn_Salir_ResultadodelRegistro.Text = "Salir";
            this.btn_Salir_ResultadodelRegistro.UseVisualStyleBackColor = true;
            this.btn_Salir_ResultadodelRegistro.Click += new System.EventHandler(this.btn_Salir_ResultadodelRegistro_Click);
            // 
            // dtp_ResultadoFechaNacimiento
            // 
            this.dtp_ResultadoFechaNacimiento.Location = new System.Drawing.Point(598, 32);
            this.dtp_ResultadoFechaNacimiento.Name = "dtp_ResultadoFechaNacimiento";
            this.dtp_ResultadoFechaNacimiento.Size = new System.Drawing.Size(200, 27);
            this.dtp_ResultadoFechaNacimiento.TabIndex = 16;
            // 
            // frm4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(843, 504);
            this.ControlBox = false;
            this.Controls.Add(this.grpResultadoEmpleado);
            this.Controls.Add(this.grpDatosEmpleado);
            this.Name = "frm4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro de empleado";
            this.grpDatosEmpleado.ResumeLayout(false);
            this.grpDatosEmpleado.PerformLayout();
            this.grpResultadoEmpleado.ResumeLayout(false);
            this.grpResultadoEmpleado.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpDatosEmpleado;
        private System.Windows.Forms.ComboBox cmbMantenimientoGenero;
        private System.Windows.Forms.TextBox txtMantenimientoEdad;
        private System.Windows.Forms.TextBox txtMantenimientoSegundoApellido;
        private System.Windows.Forms.TextBox txtMantenimientoPrimerApellido;
        private System.Windows.Forms.Label lbl_MantenimientoGenero;
        private System.Windows.Forms.Label lbl_MantenimientoEdad;
        private System.Windows.Forms.Label lbl_MantenimientoFechaNacimiento;
        private System.Windows.Forms.Label lbl_MantenimientoSegundoApellido;
        private System.Windows.Forms.Label lbl_MantenimientoPrimerApellido;
        private System.Windows.Forms.Label lbl_MantenimientoNombre;
        private System.Windows.Forms.TextBox txtMantenimientoNombre;
        private System.Windows.Forms.TextBox txtMantenimientoCédula;
        private System.Windows.Forms.Label lbl_MantenimientoCédula;
        private System.Windows.Forms.ComboBox cmbMantenimientoProfesion;
        private System.Windows.Forms.Label lbl_MantenimientoProfesión;
        private System.Windows.Forms.GroupBox grpResultadoEmpleado;
        private System.Windows.Forms.TextBox txtResultadoMantenimientoFechaNacimiento;
        private System.Windows.Forms.TextBox txtResultadoMantenimientoEdad;
        private System.Windows.Forms.TextBox txtResultadoMantenimientoSexo;
        private System.Windows.Forms.Label lbl_ResultadoMantenimientoEdad;
        private System.Windows.Forms.Label lbl_ResultadoMantenimientoFechaNacimiento;
        private System.Windows.Forms.Label lbl_ResultadoMantenimientoGenero;
        private System.Windows.Forms.Label lbl_ResultadoMantenimientoNombre;
        private System.Windows.Forms.TextBox txtResultadoMantenimientoNombre;
        private System.Windows.Forms.TextBox txtResultadoMantenimientoCédula;
        private System.Windows.Forms.Label lbl_ResultadoMantenimientoCédula;
        private System.Windows.Forms.Button btn_Guardar_DatosEmpleado;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btn_Limpiar_DatosEmpleado;
        private System.Windows.Forms.Button btn_Salir_ResultadodelRegistro;
        private System.Windows.Forms.DateTimePicker dtp_ResultadoFechaNacimiento;
    }
}